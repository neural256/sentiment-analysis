from pathlib import Path
from typing import Optional

import pandas as pd
from sklearn.datasets import fetch_openml


def _fetch_openml_robust(data_id: int):
    try:
        return fetch_openml(data_id=data_id, as_frame=True, parser="auto")
    except TypeError:
        return fetch_openml(data_id=data_id, as_frame=True)


def _select_text_column(data: pd.DataFrame) -> str:
    candidate_names = [
        "text",
        "tweet",
        "tweets",
        "tweet_text",
        "content",
        "message",
        "Text",
        "Tweet",
        "Tweets",
    ]

    for name in candidate_names:
        if name in data.columns:
            return name

    if data.shape[1] == 1:
        return data.columns[0]

    object_columns = [
        col for col in data.columns
        if data[col].dtype == "object" or str(data[col].dtype).startswith("string")
    ]

    if not object_columns:
        raise ValueError("Could not find a text column in the OpenML dataset.")

    avg_lengths = {
        col: data[col].astype(str).str.len().mean()
        for col in object_columns
    }

    return max(avg_lengths, key=avg_lengths.get)


def _extract_target(openml_bunch, frame: pd.DataFrame) -> pd.Series:
    if getattr(openml_bunch, "target", None) is not None:
        target = openml_bunch.target

        if isinstance(target, pd.DataFrame):
            if target.shape[1] != 1:
                raise ValueError("Expected one target column, but got multiple.")
            return target.iloc[:, 0]

        return pd.Series(target)

    candidate_target_names = [
        "label",
        "target",
        "class",
        "sentiment",
        "airline_sentiment",
    ]

    for name in candidate_target_names:
        if name in frame.columns:
            return frame[name]

    raise ValueError("Could not find target labels in the OpenML dataset.")


def load_airline_tweets_from_openml(
    data_id: int = 43397,
    raw_output_path: Optional[Path] = None,
) -> pd.DataFrame:
    print(f"Downloading/loading OpenML dataset with data_id={data_id} ...")

    bunch = _fetch_openml_robust(data_id=data_id)

    data = bunch.data.copy()
    frame = bunch.frame.copy() if bunch.frame is not None else data.copy()

    print("\nAvailable feature columns:", list(data.columns))

    target = _extract_target(bunch, frame)
    text_column = _select_text_column(data)

    print("Selected text column:", text_column)

    df = pd.DataFrame({
        "text": data[text_column].astype(str),
        "label": target.astype(str),
    })

    df = df.dropna()
    df["text"] = df["text"].astype(str).str.strip()
    df["label"] = df["label"].astype(str).str.strip()

    df = df[df["text"].str.len() > 0].reset_index(drop=True)

    if raw_output_path is not None:
        raw_output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(raw_output_path, index=False)
        print(f"Saved normalized raw dataset to: {raw_output_path}")

    return df
